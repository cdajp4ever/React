// leave off @2x/@3x
const images = {
  logo: require('../Images/tinder-logo.png'),
  chat: require('../Images/chatting.png'),
  harold: require('../Images/Profiles/harold.jpg'),
  like: require('../Images/like.png'),
  nope: require('../Images/nope.png'),
  boost: require('../Images/boost.png'),
  superLike: require('../Images/super-like.png'),
  rewind: require('../Images/rewind.png'),
}

export default images
